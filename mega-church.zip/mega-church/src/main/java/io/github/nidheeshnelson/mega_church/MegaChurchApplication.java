package io.github.nidheeshnelson.mega_church;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MegaChurchApplication {

	public static void main(String[] args) {
		SpringApplication.run(MegaChurchApplication.class, args);
	}

}
